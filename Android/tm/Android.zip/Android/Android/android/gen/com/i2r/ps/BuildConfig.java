/** Automatically generated file. DO NOT MODIFY */
package com.i2r.ps;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}